# Imprime todos los números enteros del 1 al 10
for i in range(1, 11):
    print(i)

# Imprime todos los números enteros del 1 al 1000
for i in range(1, 1001):
    print(i)

# Imprime todos los números enteros del 20 al 500 saltando de 10 en 10
for i in range(20, 501, 10):
    print(i)

# Imprime todos los números enteros del 10 al 0
for i in range(10, -1, -1):
    print(i)