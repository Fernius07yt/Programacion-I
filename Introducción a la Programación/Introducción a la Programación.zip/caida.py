# Bucle for
for i in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
    tiempo = i
    velocidad = 9.8 * tiempo
    espacio = 0.5 * 9.8 * tiempo**2
    print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")

# Forma antigua de programar, sin bucles (no recomendable):
# tiempo = 0
tiempo = 0
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 1
tiempo = 1
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 2
tiempo = 2
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 3
tiempo = 3
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 4
tiempo = 4
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 5
tiempo = 5
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 6
tiempo = 6
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 7
tiempo = 7
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 8
tiempo = 8
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 9
tiempo = 9
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")
# tiempo = 10
tiempo = 10
velocidad = 9.8 * tiempo
espacio = 0.5 * 9.8 * tiempo**2
print(f"t = {tiempo}, v = {velocidad} m/s, {espacio} m recorridos.")