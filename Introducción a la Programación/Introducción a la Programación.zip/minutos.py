# Entrada
edad:int = int(input("Edad: "))

# Procesamiento
minutos:int = edad * 365 * 24 * 60

# Salida
print(f"Si tienes {edad} años, has vivido al menos {minutos} minutos.")