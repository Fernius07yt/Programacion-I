# Entrada
a:int = int(input("a: "))
b:int = int(input("b: "))

# Procesamiento
menor:int = 0

if (a < b):
    menor = a
else:
    menor = b

# Salida
print(menor)