nombre = input("¿Como te llamas?")
valor = print("hola ", nombre)
print(valor)