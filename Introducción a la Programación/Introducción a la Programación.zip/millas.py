# Entrada
millas:float = float(input("Millas: "))

# Procesamiento
kilometros:float = millas * 1.609

# Salida
print(f"{millas} millas son {kilometros} km")