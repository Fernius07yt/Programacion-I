print("¿Cuál es la capital de Francia?")
print("1) Madrid")
print("2) Paris")
print("3) Helsinki")

respuesta:str = input("¿Respuesta? (1/2/3) ")

while (respuesta != "2"):
    print("No, te has equivocado")
    respuesta = input("¿Respuesta? (1/2/3) ")

print("¡Correcto!")

print("¿Cuál es la capital de Finlandia?")
print("1) Madrid")
print("2) Paris")
print("3) Helsinki")

respuesta:str = input("¿Respuesta? (1/2/3) ")

while (respuesta != "3"):
    print("No, te has equivocado")
    respuesta = input("¿Respuesta? (1/2/3) ")

print("¡Correcto!")

print("¿Cuál es la capital de España?")
print("1) Madrid")
print("2) Paris")
print("3) Helsinki")

respuesta:str = input("¿Respuesta? (1/2/3) ")

while (respuesta != "1"):
    print("No, te has equivocado")
    respuesta = input("¿Respuesta? (1/2/3) ")

print("¡Correcto!")