dolares:float = float(input("Introduce el número de dólares: "))
euros:float = dolares * 0.91
print(euros)